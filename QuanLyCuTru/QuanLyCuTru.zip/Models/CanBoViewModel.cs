﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace QuanLyCuTru.Models
{
    public class CanBoViewModel
    {
        public int TongSo { get; set; }
        public int DangKyHomNay { get; set; }
        public int ChoDuyet { get; set; }
        public int HetHan  { get; set; }
    }
}